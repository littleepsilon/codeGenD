
# -*- coding:utf-8 -*-

#
# time:        21:36
# date:        2020-10-15
# description: builder, container, maker
# author:      david


# import pyModule
# import sys
# import os
 

# import 3rd-part Moudle
 
# sys.path.append( os.path.split( os.path.realpath(__file__) )[0] + '' )
 
# import usrModule
from codeGenD.basic.cgBasic  import c_cgbasic
 
class c_snippts(c_cgbasic):
    def __init__(self):
        c_cgbasic.__init__(self)
        pass

class c_snippts_container(c_snippts):
    def __init__(self):
        c_snippts.__init__(self)
        pass

class c_snippts_builder(c_snippts):
    def __init__(self):
        c_snippts.__init__(self)
        pass

class c_snippts_maker(c_snippts):
    def __init__(self):
        c_snippts.__init__(self)
        pass
 
