# -*- coding:utf-8 -*-
#
# time:        19:32
# date:        2020/06/06
# description: none
# author:      david
# 

# import pylib
import sys

# import 3rdPart lib

# import usrLib

# global var

# var = None