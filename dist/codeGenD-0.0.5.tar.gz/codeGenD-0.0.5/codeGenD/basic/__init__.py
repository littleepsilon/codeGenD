# -*- coding:utf-8 -*-

#
# time:        23:22
# date:        2020-07-07
# description: test Description on this line 
# author:      untitled


# import pyModule
# import sys
# import os

# import 3rd-part Moudle

# sys.path.append( os.path.split( os.path.realpath(__file__) )[0] + '' )

# import usrModule

